a = input()
b = input()
combin = a + b
setCom = set(combin)

ans = ''
for letter in setCom:
    acount = a.count(letter)
    bcount = b.count(letter)
    if acount > bcount:
        ans += letter * acount
    else:
        ans += letter * bcount

print(ans)