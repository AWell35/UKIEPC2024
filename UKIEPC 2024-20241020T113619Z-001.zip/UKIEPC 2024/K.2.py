coreinfo = '10 6 3'
coreinfoList = coreinfo.split()
exsistinglines = "4"
scarf = "4 1 6 4"

strips = coreinfoList[0]
colours = coreinfoList[1]
spacing = coreinfoList[2]

colourdic = {}
for colour in range(int(colours)):
    colourdic[colour] = 0


scarfList = scarf.split()
for i in range (len(scarfList)):
    scarfList[i]  = int(scarfList[i])

scarfcolour = set(scarfList)
for colours in scarfList:
    colourdic[colours] = scarfList.count(colours)

#scarf_split = scarf.split(' ')
#scarf_split = scarf_split[-spacing:len(scarf) - 1]

#if len(set(scarf_split)) < len(scarf_split):
    print('impossible')
#elif spacing > colours and strips > spacing:
  # print('impossible')
#else:
lowest = sorted(colourdic.values())

print(lowest)