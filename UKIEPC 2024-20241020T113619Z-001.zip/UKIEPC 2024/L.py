ans = '1 '
terms = {'leg':'🦵', 
         'arm': '💪', 
         'biceps':'💪',
         'rest': '😎'}

number_execrise = int(input())

inputs = []
for i in range(number_execrise):
    inputs.append(input())

routine = []
for excercise in inputs:
    for term in terms:
        if term in excercise:
            routine.append(terms[term])

routine = routine[0:number_execrise]
c = 2
count = 0
for num in range(31):
    ans += f'{routine[count]}'
    if count >= number_execrise - 1:
       count = 0 
    else:
        count += 1
    if (num + 1) % 7 == 0:
        ans += f'\n{c} '
        c += 1
print(ans)