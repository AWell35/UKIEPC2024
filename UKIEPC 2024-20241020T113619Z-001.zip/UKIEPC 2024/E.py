inpNum = int(input())
ans = 0
valinp = input()
values = valinp.split()

for i in range (len(values)):
    values[i]  = int(values[i])
removed = []

for index in range(len(values)-1):
    if values[index] < values[index - 1] :
        removed.append(values[index])

print(removed)
cons = 1
temp = removed.pop()
for i in range(len(removed)):
    new = removed.pop()
    if temp - 1 == new:
        cons += 1
    else:
        if cons > 1:
            ans += 2 ** cons
            cons = 1
        ans += 1
    temp = new

print(ans)