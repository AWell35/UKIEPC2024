import random
inputs = input()
inputs = inputs.split(' ')
for i in range(len(inputs)):
    inputs[i] = int(inputs[i])

strips = inputs[0]
colours = inputs[1]
spacing = inputs[2]

already = int(input())

scarf = input()
scarf_list = scarf.split()

scarf_split = scarf.split(' ')
scarf_split = scarf_split[-spacing:len(scarf) - 1]

if len(set(scarf_split)) < len(scarf_split):
    print('impossible')
elif spacing > colours and strips > spacing:
   print('impossible')
else:
    colour_list = []
    for i in range(colours):
        colour_list.append(i)

    for i in range(strips - 1):
        scarf_split = scarf.split(' ')
        scarf_split = scarf_split[-spacing:len(scarf) - 1]

        new_colour = random.randint(1, colours)
        counter = 0
        while str(new_colour) in scarf_split:
            counter += 1
            if counter > colours - 1:
                counter = 0
            new_colour = colour_list[counter]
        scarf += f' {new_colour}'

    print(scarf)
